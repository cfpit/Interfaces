import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>¡Hola Mundo!</h1>
        <p>Mi primera aplicación React 🚀</p>
        <p>¡Estoy aprendiendo React!</p>
      </header>
    </div>
  );
}

export default App;
